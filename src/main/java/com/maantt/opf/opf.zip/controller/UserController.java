package com.maantt.opf.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.maantt.opf.entity.UserEntity;
import com.maantt.opf.services.UserService;

@RestController
public class UserController {
	@Autowired
	private UserService service;
	@CrossOrigin(origins = "http://localhost:4200")
	@GetMapping("/getuserentitylist")
	public List<UserEntity> fetchUserEntityList(){
		List<UserEntity> user= new ArrayList<UserEntity>();
		//logic to fetch list from database
		user = service.fetchUserEntityList();
		return user;
	}
	@CrossOrigin(origins = "http://localhost:4200")
	@PostMapping("/adduserentitylist")
	public UserEntity saveUserEntityList(@RequestBody UserEntity UserEntity){
		return service.saveUserEntityToDB(UserEntity);
	}
	@CrossOrigin(origins = "http://localhost:4200")
	@GetMapping("/getuserentitybyid/{id}")
	public UserEntity fetchUserEntityById(@PathVariable int id){
		return service.fetchUserEntityById(id).get();
	}
	@CrossOrigin(origins = "http://localhost:4200")
	@DeleteMapping("/deleteuserentitybyid/{id}")
	public String DeleteUserEntityById(@PathVariable int id){
	return service.deleteUserEntityById(id);	
	}
	
	
	
	

}
