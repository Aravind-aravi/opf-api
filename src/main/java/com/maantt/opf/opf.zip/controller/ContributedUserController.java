package com.maantt.opf.controller;


import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;


import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.maantt.opf.services.ContributedUserService;
import com.maantt.opf.entity.ContributedUserEntity;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
public class ContributedUserController {
	
	@Autowired
	private ContributedUserService service;

	@CrossOrigin(origins = "http://localhost:4200")
	@GetMapping("/getcontributeduserentitylist")
	public List<ContributedUserEntity> fetchContributedUserEntityList(){
		List<ContributedUserEntity> user= new ArrayList<ContributedUserEntity>();
		//logic to fetch list from database
		user = service.fetchContributedUserEntityList();
		return user;
	}
	
	@CrossOrigin(origins = "http://localhost:4200")
	@PostMapping("/addcontributeduserentitylist")
	public ContributedUserEntity saveContributedUserEntityList(@RequestBody ContributedUserEntity ContributedUserEntity){
		return service.saveContributedUserEntityToDB(ContributedUserEntity);
	}
	
	@CrossOrigin(origins = "http://localhost:4200")
	@GetMapping("/getcontributeduserentitybyid/{id}")
	public ContributedUserEntity fetchContributedUserEntityById(@PathVariable int id){
		return service.fetchContributedUserEntityById(id).get();
	}
	
	@CrossOrigin(origins = "http://localhost:4200")
	@DeleteMapping("/deletecontributeduserentitybyid/{id}")
	public String DeleteContributedUserEntityById(@PathVariable int id){
	return service.deleteContributedUserEntityById(id);	
	}
	
	

}
