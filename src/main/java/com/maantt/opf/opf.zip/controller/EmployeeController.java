package com.maantt.opf.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.maantt.opf.entity.EmployeeEntity;
import com.maantt.opf.services.EmployeeService;

@RestController
public class EmployeeController {
	@Autowired
	private EmployeeService service;
	@CrossOrigin(origins = "http://localhost:4200")
	@GetMapping("/getemployeeentitylist")
	public List<EmployeeEntity> fetchEmployeeEntityList(){
		List<EmployeeEntity> employee= new ArrayList<EmployeeEntity>();
		//logic to fetch list from database
		employee = service.fetchEmployeeEntityList();
		return employee
				
				;
	}
	@CrossOrigin(origins = "http://localhost:4200")
	@PostMapping("/addemployeeentitylist")
	public EmployeeEntity saveEmployeeEntityList(@RequestBody EmployeeEntity EmployeeEntity){
		return service.saveEmployeeEntityToDB(EmployeeEntity);
	}
	@CrossOrigin(origins = "http://localhost:4200")
	@GetMapping("/getemployeeentitybyid/{id}")
	public EmployeeEntity fetchEmployeeEntityById(@PathVariable int id){
		return service.fetchEmployeeEntityById(id).get();
	}
	@CrossOrigin(origins = "http://localhost:4200")
	@DeleteMapping("/deleteemployeeentitybyid/{id}")
	public String DeleteEmployeeEntityById(@PathVariable int id){
	return service.deleteEmployeeEntityById(id);	
	}
	


}
