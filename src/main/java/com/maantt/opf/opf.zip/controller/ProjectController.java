package com.maantt.opf.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.maantt.opf.entity.ProjectEntity;
import com.maantt.opf.services.ProjectService;

@RestController

public class ProjectController {
	@Autowired
	private ProjectService service;
	@CrossOrigin(origins = "http://localhost:4200")
	
	@GetMapping("/getprojectentitylist")
	public List<ProjectEntity> fetchProjectEntityList(){
		List<ProjectEntity> project= new ArrayList<ProjectEntity>();
		//logic to fetch list from database
		project = service.fetchProjectEntityList();
		return project;
	}
	
	@CrossOrigin(origins = "http://localhost:4200")
	@GetMapping("/getprojectentitybyid/{id}")
	public ProjectEntity fetchProjectEntityById(@PathVariable int id){
		return service.fetchProjectEntityById(id).get();
	}
	
	@CrossOrigin(origins = "http://localhost:4200")
	@PostMapping("/addprojectentitylist")
	public ProjectEntity saveProjectEntityList(@RequestBody ProjectEntity ProjectEntity){
		return service.saveProjectEntityToDB(ProjectEntity);
	}
	
	@CrossOrigin(origins = "http://localhost:4200")
	@PutMapping("/updateprojectentitylist")
	public ProjectEntity updateProjectEntityList(@RequestBody ProjectEntity ProjectEntity){
		return service.saveProjectEntityToDB(ProjectEntity);
	}
	
	
	@CrossOrigin(origins = "http://localhost:4200")
	@DeleteMapping("/deleteprojectentitybyid/{id}")
	public String DeleteProjectEntityById(@PathVariable int id){
	return service.deleteProjectEntityById(id);	
	}
	

}
