package com.maantt.opf.entity;


import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="contributed_user")

public class ContributedUserEntity {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer id;
	
	private String file_name;
	private String file_type;
	
	@Lob
	private byte[] data;


	private String approved_status;
	

	@OneToMany(targetEntity = UserEntity.class,cascade = CascadeType.ALL)
	@JoinColumn(name="contributeduser_id",referencedColumnName="id")
	private List<UserEntity>  userentity;



	public ContributedUserEntity() {
	}

	public ContributedUserEntity( String file_name, String file_type, byte[] data) {
		super();
		this.file_name = file_name;
		this.file_type = file_type;
		this.data = data;
	}

	public ContributedUserEntity(Integer id, String file_name, String file_type, byte[] data, String approved_status,
			List<UserEntity> userentity) {
		super();
		this.id = id;
		this.file_name = file_name;
		this.file_type = file_type;
		this.data = data;
		this.approved_status = approved_status;
		this.userentity = userentity;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getFile_name() {
		return file_name;
	}

	public void setFile_name(String file_name) {
		this.file_name = file_name;
	}

	public String getFile_type() {
		return file_type;
	}

	public void setFile_type(String file_type) {
		this.file_type = file_type;
	}

	public byte[] getData() {
		return data;
	}

	public void setData(byte[] data) {
		this.data = data;
	}

	public String getApproved_status() {
		return approved_status;
	}

	public void setApproved_status(String approved_status) {
		this.approved_status = approved_status;
	}

	public List<UserEntity> getUserentity() {
		return userentity;
	}

	public void setUserentity(List<UserEntity> userentity) {
		this.userentity = userentity;
	}

		
	
	
}