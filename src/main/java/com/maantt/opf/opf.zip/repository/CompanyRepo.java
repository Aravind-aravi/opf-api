package com.maantt.opf.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.maantt.opf.entity.CompanyEntity;

public interface CompanyRepo extends JpaRepository<CompanyEntity, Integer>{

}
