package com.maantt.opf.repository;


import org.springframework.data.jpa.repository.JpaRepository;

import com.maantt.opf.entity.ProjectEntity;

public interface ProjectRepo extends JpaRepository<ProjectEntity, Integer>{


}
