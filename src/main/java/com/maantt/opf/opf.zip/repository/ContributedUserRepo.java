package com.maantt.opf.repository;


import org.springframework.data.jpa.repository.JpaRepository;

import com.maantt.opf.entity.ContributedUserEntity;

public interface ContributedUserRepo extends JpaRepository<ContributedUserEntity, Integer>{


}
